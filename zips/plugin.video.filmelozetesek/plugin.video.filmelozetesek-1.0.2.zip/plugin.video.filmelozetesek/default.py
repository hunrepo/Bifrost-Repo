# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2015 - Simple TechNerd
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

thisAddon = xbmcaddon.Addon(id='plugin.video.filmelozetesek')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media')).decode('utf-8')


channellist=[
        ("A Company Hungary", "user/acompanyhungary", MediaDir + '\\acompany.png'),
        ("ADS Service", "user/ADSService1", MediaDir + '\\ads.png'),
        ("Big Bang Media", "user/bigbang201111", MediaDir + '\\bigbang.jpg'),
        ("Cinetel", "user/CinetelHungary", MediaDir + '\\cinetel.png'),
        ("Cinenuovo", "user/CinenuovoFilm", MediaDir + '\\cinenuovo.png'),
        ("Cirko Gejzir", "user/cgzir2010", MediaDir + '\\cirko.png'),
        ("Forum Hungary", "user/ForumHungary", MediaDir + '\\forumhungary.png'),		
        ("Freeman Film", "user/freemanfilmhun", MediaDir + '\\freeman.jpg'),
        ("InterCom", "user/InterComHun", MediaDir + '\\intercom.png'),
        ("Magyarhangya", "user/magyarhangya", MediaDir + '\\magyarhangya.png'),
        ("Mozinet", "user/mozinet", MediaDir + '\\mozinet.png'),
        ("Pannonia Entertainment", "channel/UCzzXmYzPp7qI4gRt-AuafcA", MediaDir + '\\pannonia.jpg'),
        ("PARLUX Entertainment Magyarorszag", "user/PARLUXFILM", MediaDir + '\\parlux.png'),
        ("Pro Video Film (BD/DVD)", "user/ProVideoFilmHUN", MediaDir + '\\provideo.png'),
        ("UIP-Duna Film", "user/Michele0222", MediaDir + '\\uipduna.png'),
        ("Vertigo Media", "user/VertigoMediaKft", MediaDir + '\\vertigo.png'),
]


# Entry point
def run():
    plugintools.log("filmelozetesek.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("filmelozetesek.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )


run()